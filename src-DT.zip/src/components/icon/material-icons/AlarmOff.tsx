import React, { SVGProps } from 'react';

const SvgAlarmOff = (props: SVGProps<SVGSVGElement>) => {
	return (
		<svg
			xmlns='http://www.w3.org/2000/svg'
			height='1em'
			viewBox='0 0 24 24'
			width='1em'
			fill='currentColor'
			className='svg-icon'
			{...props}>
			<path d='M0 0h24v24H0V0z' fill='none' />
			<path d='M10.04 6.29C10.66 6.11 11.32 6 12 6c3.86 0 7 3.14 7 7 0 .68-.11 1.34-.29 1.96l1.56 1.56c.47-1.08.73-2.27.73-3.52A9 9 0 008.47 4.72l1.57 1.57zm7.297-4.48l4.607 3.845-1.28 1.535-4.61-3.843zm1.903 16.51l-1.43-1.43-9.7-9.7-1.43-1.43-.74-.74L4.52 3.6l-1.5-1.5-1.41 1.41 1.37 1.37-.92.77 1.28 1.54 1.06-.88.8.8A8.964 8.964 0 003 13a9 9 0 009 9c2.25 0 4.31-.83 5.89-2.2l2.1 2.1 1.41-1.41-2.16-2.17zM12 20c-3.86 0-7-3.14-7-7 0-1.7.61-3.26 1.62-4.47l9.85 9.85A6.956 6.956 0 0112 20zM7.48 3.73l.46-.38-1.28-1.54-.6.5z' />
		</svg>
	);
}

export default SvgAlarmOff;
